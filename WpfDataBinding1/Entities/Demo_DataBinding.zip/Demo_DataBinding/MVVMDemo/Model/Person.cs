﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVVMDemo.Model
{
    public class Person
    {
        public string PersonName { get; set; }
    }
}
