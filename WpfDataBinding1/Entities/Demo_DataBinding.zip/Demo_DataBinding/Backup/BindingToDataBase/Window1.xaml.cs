﻿using System.Linq;
using System.Windows;
using System.Windows.Data;

namespace BindingToDataBase
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        CollectionView view;
        #region DataSet
        //NorthwindDataSet ds = new NorthwindDataSet();
        //NorthwindDataSetTableAdapters.EmployeesTableAdapter ta = new BindingToDataBase.NorthwindDataSetTableAdapters.EmployeesTableAdapter();
        //NorthwindDataSetTableAdapters.TableAdapterManager tam = new BindingToDataBase.NorthwindDataSetTableAdapters.TableAdapterManager();
        #endregion
 
        NorthwindDataContext db;


        public Window1()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            db = new NorthwindDataContext();
            DataContext = db.Employees.ToList<Employee>();
            view = (CollectionView)CollectionViewSource.GetDefaultView(DataContext);
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            view.MoveCurrentToNext();

        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            view.MoveCurrentToPrevious();
            
        }

        
    }
}
