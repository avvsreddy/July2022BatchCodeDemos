﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace ShoppingCartService
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
    public class ShoppingCart : IShoppingCart
    {
        #region IShoppingCart Members

        private List<CartItem> cart = new List<CartItem>();

        public void AddItem(CartItem item)
        {
            cart.Add(item);
        }

        public void RemoveItem(int id)
        {
    //        foreach (var item in cart)
    //{
    //     if (item.ItemId == id)
    //         cart.Remove(item)
    //}

            cart.Remove(cart.FirstOrDefault(ci => ci.ItemId == id));
        }

        public List<CartItem> GetCartItems()
        {
            return cart;
        }

        public double GetBillAmount()
        {
            return cart.Sum(i => i.Price * i.Quantity);
        }

        public void Checkout()
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
