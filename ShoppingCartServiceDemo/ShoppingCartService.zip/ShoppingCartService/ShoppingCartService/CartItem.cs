﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace ShoppingCartService
{
    [DataContract]
    public class CartItem
    {
        [DataMember]
        public int ItemId { get; set; }
        [DataMember]
        public string ItemName { get; set; }
        [DataMember]
        public int Quantity { get; set; }
        [DataMember]
        public double Price { get; set; }
    }
}
