﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace ShoppingCartService
{
    [ServiceContract(SessionMode=SessionMode.Required)]
    public interface IShoppingCart
    {
        [OperationContract(IsInitiating=true,IsTerminating=false)]
        void AddItem(CartItem item );
        [OperationContract(IsInitiating = false, IsTerminating = false)]
        void RemoveItem(int id);
        [OperationContract(IsInitiating = false, IsTerminating = false)]
        List<CartItem> GetCartItems();
        [OperationContract(IsInitiating = false, IsTerminating = false)]
        double GetBillAmount();
        [OperationContract(IsInitiating = false, IsTerminating = true)]
        void Checkout();
    }
}
